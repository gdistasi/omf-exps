#!/bin/bash
echo "OPTIND starts at $OPTIND"
while getopts ":i:q:lr:d" optname
  do
    case "$optname" in
      "i")
        #echo "Configured interface = $OPTARG"
        interface="$OPTARG"
        ;;
      "l")
        #echo "logger activated"
        vlog="-l"
        ;;
      "r")
        #echo "Route et Reputation logger activated: refresh each $OPTARG seconds"
        rtlog="-r $OPTARG"
        ;;
      "d")
        #echo "daemon"
        daemon="-d"
        ;;
      "?")
        echo "Unknown option $OPTARG"
        ;;
      ":")
        echo "No argument value for option $OPTARG"
        ;;
      *)
      # Should not occur
        echo "Unknown error while processing options"
        ;;
    esac
    # echo "OPTIND is now $OPTIND"
  done
    aodvd -i $interface $vlog $rtlog $daemon
