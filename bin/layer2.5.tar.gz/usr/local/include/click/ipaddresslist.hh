#error "The IPAddressList class is no longer available.  Use Vector<IPAddress> instead."
