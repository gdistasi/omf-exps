#ifndef DEQueue
#warning "DEQueue is deprecated, use Deque and <click/deque.hh> instead"
#include <click/deque.hh>
#define DEQueue Deque
#endif
