#ifndef CLICK_BIGHASHMAP_HH
#define CLICK_BIGHASHMAP_HH

// This file is here for compatibility only.
#include <click/hashmap.hh>

#endif
