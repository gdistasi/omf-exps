#ifdef __cplusplus
# undef new
# undef this
# undef delete
# undef class
# undef virtual
# undef typename
# undef protected
# undef public
# undef namespace
# undef false
# undef true
#endif
#undef CLICK_CXX_PROTECTED
